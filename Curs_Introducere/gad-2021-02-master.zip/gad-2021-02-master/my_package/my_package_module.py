my_age = 30
print('my_package.my_package_module name = ', __name__)
