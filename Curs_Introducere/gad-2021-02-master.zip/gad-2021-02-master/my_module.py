my_age = 20

# ....


str_ = 'another custom string'  # inline comment

# ....
print('my_module name = ', __name__)
